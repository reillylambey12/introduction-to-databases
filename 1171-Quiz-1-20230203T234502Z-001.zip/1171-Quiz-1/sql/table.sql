DROP TABLE IF EXISTS employees ;

CREATE TABLE employees(
    employee_id serial PRIMARY KEY,
    person_name text NOT NULL,
    job text NOT NULL,
    salary int NOT NULL,
    Created_at timestamp(0)with time zone NOT NULL DEFAULT NOW()
);

INSERT INTO employees(person_name,job,salary)
VALUES('jefferson','teacher',2500);

INSERT INTO employees(person_name,job,salary)
VALUES('tammy','taxi',23000);

INSERT INTO employees(person_name,job,salary)
VALUES('morgan','pilot',25000);

INSERT INTO employees(person_name,job,salary)
VALUES('william','ararchitecture',25000);

INSERT INTO employees(person_name,job,salary)
VALUES('luke','software engineer',24000);

SELECT* 
FROM employees ORDER BY person_name DESC;

